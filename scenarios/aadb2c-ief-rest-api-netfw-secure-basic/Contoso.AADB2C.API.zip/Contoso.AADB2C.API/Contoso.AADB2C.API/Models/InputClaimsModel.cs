﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Contoso.AADB2C.API.Models
{
    public class InputClaimsModel
    {
        public string email { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
    }
}