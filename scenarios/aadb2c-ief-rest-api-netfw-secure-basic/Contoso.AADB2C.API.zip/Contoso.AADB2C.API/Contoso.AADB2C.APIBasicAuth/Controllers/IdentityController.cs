﻿using Contoso.AADB2C.APIBasicAuth.Models;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Web.Http;

namespace Contoso.AADB2C.APIBasicAuth.Controllers
{
    [Authorize]
    public class IdentityController : ApiController
    {
        [HttpPost]
        public IHttpActionResult SignUp()
        {
            // If not data came in, then returen
            if (this.Request.Content == null) throw new Exception();

            // Read the input claims from the request body
            string input = Request.Content.ReadAsStringAsync().Result;

            // Check input content value
            if (string.IsNullOrEmpty(input))
            {
                return Content(HttpStatusCode.Conflict, new B2CResponseContent("Request content is empty", HttpStatusCode.Conflict));
            }

            // Convert the input string into InputClaimsModel object
            InputClaimsModel inputClaims = JsonConvert.DeserializeObject(input, typeof(InputClaimsModel)) as InputClaimsModel;

            if (inputClaims == null)
            {
                return Content(HttpStatusCode.Conflict, new B2CResponseContent("Can not deserialize input claims", HttpStatusCode.Conflict));
            }

            // Run input validation
            if (inputClaims.firstName.ToLower() == "test")
            {
                return Content(HttpStatusCode.Conflict, new B2CResponseContent("Test name is not valid, please provide a valid name", HttpStatusCode.Conflict));
            }

            // Create output claims object and set the loyalty number with random value
            OutputClaimsModel outputClaims = new OutputClaimsModel();
            outputClaims.loyaltyNumber = new Random().Next(100, 1000).ToString();

            // Return the output claim(s)
            return Ok(outputClaims);
        }
    }
}
