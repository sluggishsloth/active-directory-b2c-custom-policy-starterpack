﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(Contoso.AADB2C.APIBasicAuth.Startup))]
namespace Contoso.AADB2C.APIBasicAuth
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            app.Use<ClientAuthMiddleware>();
        }
    }
}
